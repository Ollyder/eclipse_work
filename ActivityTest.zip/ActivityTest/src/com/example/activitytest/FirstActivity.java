package com.example.activitytest;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;
public class FirstActivity extends Activity {
 @Override
 protected void onCreate(Bundle savedInstanceState){
	 super.onCreate(savedInstanceState);
	// requestWindowFeature(Window.FEATURE_NO_TITLE);
	 setContentView(R.layout.first_layout);
	 Log.d("mmm", "dothis");
	 Button button1 = (Button) findViewById(android.R.id.button1);
	 button1.setOnClickListener(new OnClickListener(){
		 @Override
		 public void onClick(View v){
			 Toast.makeText(FirstActivity.this,"you clicked Button 1",
					 Toast.LENGTH_SHORT).show();
		 }
	 });
 }
}
